# Heavy Metal Prediction and Analysis Tool

An AI-inspired React web tool for predicting soil heavy metal content based on key parameters.

## Features
- Input: Organic Matter, pH, CEC
- Output: Predicted levels of Cd, Cr, Cu, Ni, Pb, Zn
- Visualized with Recharts

## How to Run
1. Upload to GitHub
2. Deploy on Vercel (it auto-detects React)
3. Visit live link to try the tool

---

👨‍💻 Created by: [Your Name]  
🎓 3MTT FellowID: [Your FellowID]